<div class="alert alert-success hidden" id="mensaje_div" role="alert">
    Eliminacion hecha correctamente <span id="btn_close" style="float:right;"><svg xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 12 12" width="auto" height="20">
            <path
                d="M2.22 2.22a.749.749 0 0 1 1.06 0L6 4.939 8.72 2.22a.749.749 0 1 1 1.06 1.06L7.061 6 9.78 8.72a.749.749 0 1 1-1.06 1.06L6 7.061 3.28 9.78a.749.749 0 1 1-1.06-1.06L4.939 6 2.22 3.28a.749.749 0 0 1 0-1.06Z">
            </path>
        </svg></span>
</div>