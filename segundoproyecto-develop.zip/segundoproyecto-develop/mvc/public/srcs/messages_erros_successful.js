jQuery("#btn_close").on("click",()=>{
    jQuery("#mensaje_div").hide()
});

